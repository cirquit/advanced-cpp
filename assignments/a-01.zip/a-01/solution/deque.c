
#include "deque.h"

// YOUR IMPLEMENTATION HERE
